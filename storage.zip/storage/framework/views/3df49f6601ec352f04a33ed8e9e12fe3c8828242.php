<?php
header("Location: " . URL::to('/getcode'), true, 302);
exit();
?><?php /**PATH C:\Users\BKU-PD-03\Documents\Website Versi Promosi\inventoryweb\resources\views/Admin/BarangMasuk/index.blade.php ENDPATH**/ ?>