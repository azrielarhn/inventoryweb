<?php
header("Location: " . URL::to('/getcode'), true, 302);
exit();
?><?php /**PATH C:\code\inventoryweb\resources\views/Admin/BarangKeluar/index.blade.php ENDPATH**/ ?>