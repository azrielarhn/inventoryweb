<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © <?php echo e(date('Y')); ?>

            </div>
        </div>
    </div>
</footer><?php /**PATH C:\Users\BKU-PD-03\Documents\Website\aplikasi-inventoryweb\resources\views/Master/Layouts/footer.blade.php ENDPATH**/ ?>