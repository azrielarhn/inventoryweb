<!-- MODAL GAMBAR -->
<div class="modal fade" id="Gmodaldemo8">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modal-content-demo bg-transparent border-0 shadow-none">
            <div class="modal-body text-center p-4 pb-5">
                <button type="reset" aria-label="Close" class="btn-close position-absolute" data-bs-dismiss="modal"><span aria-hidden="true">×</span></button>
                <img src="<?php echo e(url('/assets/default/barang/image.png')); ?>" width="100%" alt="profile-user" id="outputImgG" class="">
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\BKU-PD-03\Documents\Website\aplikasi-inventoryweb\resources\views/Admin/Barang/gambar.blade.php ENDPATH**/ ?>