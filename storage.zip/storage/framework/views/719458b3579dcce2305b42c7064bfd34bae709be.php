<!-- MODAL UBAH -->
<div class="modal fade" data-bs-backdrop="static" id="Umodaldemo8">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content modal-content-demo">
            <div class="modal-header">
                <h6 class="modal-title">Ubah Jenis</h6><button aria-label="Close" class="btn-close" data-bs-dismiss="modal"><span aria-hidden="true">&times;</span></button>
            </div>
            <form method="POST" name="myFormUpdate" id="myFormUpdate" enctype="multipart/form-data" onsubmit="return validateFormUpdate()">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="jenisU" class="form-label">Nama Jenis</label>
                        <input type="text" name="jenisU" id="jenisU" class="form-control" placeholder="">
                    </div>
                    <div class="form-group">
                        <label for="ket" class="form-label">Keterangan</label>
                        <textarea name="ketU" class="form-control" id="ketU" rows="4"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Simpan Perubahan <i class="fe fe-check"></i></button>
                    <a href="javascript:void(0)" class="btn btn-light" onclick="resetUpdate()" data-bs-dismiss="modal">Batal <i class="fe fe-x"></i></a>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function validateFormUpdate() {
        const jenis = document.forms["myFormUpdate"]["jenisU"].value;

        resetValidUpdate();

        if (jenis == "") {
            validasi('Nama Jenis wajib di isi!', 'warning');
            $("input[name='jenisU']").addClass('is-invalid');
            return false;
        }

    }

    function resetValidUpdate() {
        $("input[name='jenisU']").removeClass('is-invalid');
    };

    function resetUpdate() {
        resetValidUpdate();
        $("input[name='jenisU']").val('');
        $("textarea[name='ketU']").val('');
    }
</script><?php /**PATH C:\Users\BKU-PD-03\Documents\Website\aplikasi-inventoryweb\resources\views/Admin/Jenis/edit.blade.php ENDPATH**/ ?>